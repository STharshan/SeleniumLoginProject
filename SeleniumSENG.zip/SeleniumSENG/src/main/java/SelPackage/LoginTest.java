package SelPackage;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import static org.testng.AssertJUnit.assertEquals;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import dev.failsafe.internal.util.Assert;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginTest {
	WebDriver driver;
	@BeforeTest
	public void setup() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
//		WebDriverManager.edgedriver().setup();
//		driver= new EdgeDriver();
	}
	
	@Test
	public void login () {
		driver.get("https://demo.guru99.com/V4/index.php");
		
		driver.findElement(By.name("uid")).sendKeys("mngr492578");
		
		driver.findElement(By.name("password")).sendKeys("dYdEgAr");
		
		driver.findElement(By.name("btnLogin")).click();
				
		AssertJUnit.assertEquals(driver.findElement(By.xpath("//tr[@class='heading3']//td")).
		getText(), "Manger Id : mngr492578");



	}
	
	@AfterTest
	public void teardown() {
		driver.close();
		driver.quit();

	}

}
